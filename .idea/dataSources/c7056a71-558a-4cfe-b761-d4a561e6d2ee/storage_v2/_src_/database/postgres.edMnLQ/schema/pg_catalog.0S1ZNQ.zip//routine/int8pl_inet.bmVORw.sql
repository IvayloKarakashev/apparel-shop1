create function int8pl_inet(bigint, inet) returns inet
    immutable
    strict
    parallel safe
    cost 1
    language sql
as
$$
    begin
-- missing source code
end;
$$;

comment on function int8pl_inet(bigint, inet) is 'implementation of + operator';

alter function int8pl_inet(bigint, inet) owner to postgres;

